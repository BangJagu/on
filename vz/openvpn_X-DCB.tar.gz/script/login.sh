#!/bin/bash
[ "$username" == "test" ] && [ "$password" != "three" ] && exit 1
exit 0